package com.example;
import spoon.*;
import spoon.reflect.*;
import spoon.reflect.code.*;
import spoon.reflect.factory.*;
import spoon.reflect.visitor.filter.*;
import spoon.reflect.declaration.*;
import spoon.reflect.visitor.*;


public class App {

    public static void main(String[] args) {
        // Initialize Spoon launcher
        String path = "C:/Users/SIM/Desktop/javas/Ame.java";
        Launcher launcher = new Launcher();

        // Set input source folder
        launcher.addInputResource(path);

        // Build model
        launcher.buildModel();
        CtModel model = launcher.getModel();
        // transform the model
        transformModel(model);
        // print the model after the transformation
        printAST(model,launcher);
    }
    
    private static void transformModel(CtModel model) {
                model.getElements(new TypeFilter<>(CtIf.class)).forEach(ifStatement -> {
                CtExpression<Boolean> condition = ((CtIf) ifStatement).getCondition();
                CtExpression<Boolean> transformedCondition = reverseOperators(condition);
                ((CtIf) ifStatement).setCondition(transformedCondition);
               });
    }
    
   private static void printAST(CtModel model, Launcher launcher) {
        DefaultJavaPrettyPrinter printer = new DefaultJavaPrettyPrinter(launcher.getEnvironment());
        model.getAllTypes().forEach(type -> {
            printer.scan(type);
            System.out.println(printer.toString());
        });
    }

    private static CtExpression<Boolean> reverseOperators(CtExpression<Boolean> condition) {
        // Apply transformation based on the type of expression
        if (condition instanceof CtBinaryOperator) {
            CtBinaryOperator<Boolean> binaryOperator = (CtBinaryOperator<Boolean>) condition;
            // Reverse relational and logical operators
            switch (binaryOperator.getKind()) {
                case EQ:
                    return binaryOperator.clone().setKind(BinaryOperatorKind.NE);
                case NE:
                    return binaryOperator.clone().setKind(BinaryOperatorKind.EQ);
                case AND:
                    return binaryOperator.clone().setKind(BinaryOperatorKind.OR);
                case OR:
                    return binaryOperator.clone().setKind(BinaryOperatorKind.AND);
                case GT:
                    return binaryOperator.clone().setKind(BinaryOperatorKind.LE);
                case GE:
                    return binaryOperator.clone().setKind(BinaryOperatorKind.LT);
                case LT:
                    return binaryOperator.clone().setKind(BinaryOperatorKind.GE);
                case LE:
                    return binaryOperator.clone().setKind(BinaryOperatorKind.GT);
            }
        }
        return condition;
    }

}