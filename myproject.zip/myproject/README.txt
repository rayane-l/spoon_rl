type those in cmd
==================
cd ./myproject
mvn clean install
mvn exec:java -Dexec.mainClass="com.example.App"